// main.js - Application orchestrator

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    console.log('Aposonía Map initializing...');

    // Initialize UI module
    UI.init();
    console.log('UI module initialized');

    // Initialize map module
    MapModule.initMap();
    console.log('Map module initialized');

    // Load points from JSON
    MapModule.loadPoints();

    // Expose to window for debugging
    window.UI = UI;
    
    console.log('Aposonía Map ready');
    console.log('Click on map to get coordinates and create temporary markers');
    console.log('Click on red markers (if points.json loaded) to open details panel');
});
