// map.js - Map management module

const MapModule = {
    map: null,
    points: [],
    tempMarkers: [],
    permanentMarkers: [],

    // Initialize Leaflet map
    initMap() {
        // Center on Nea Paralia, Thessaloniki
        this.map = L.map('map').setView([40.6246, 22.9489], 16);

        // Add OpenStreetMap tile layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            maxZoom: 19
        }).addTo(this.map);

        // Bind map click event
        this.map.on('click', (e) => this.onMapClick(e));

        console.log('Map initialized at Nea Paralia, Thessaloniki');
    },

    // Handle map click
    onMapClick(e) {
        const lat = e.latlng.lat;
        const lng = e.latlng.lng;

        // Log coordinates
        console.log(`Clicked coordinates: Lat ${lat.toFixed(6)}, Lng ${lng.toFixed(6)}`);

        // Update coordinate display
        if (window.UI) {
            window.UI.updateCoordinateDisplay(lat, lng);
        }

        // Add temporary marker
        this.addTempMarker(lat, lng);
    },

    // Add temporary marker (development mode)
    addTempMarker(lat, lng) {
        const marker = L.marker([lat, lng], {
            icon: L.icon({
                iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
                shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
                shadowSize: [41, 41]
            })
        }).addTo(this.map);

        // Store marker with coordinates
        this.tempMarkers.push({
            marker: marker,
            lat: lat,
            lng: lng
        });

        console.log(`Temporary marker added. Total: ${this.tempMarkers.length}`);
    },

    // Load points from JSON
    async loadPoints() {
        try {
            const response = await fetch('data/points.json');
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            this.points = await response.json();
            
            console.log(`Loaded ${this.points.length} points from JSON`);
            
            // Validate and render markers
            this.renderPermanentMarkers();
            
        } catch (error) {
            console.error('Error loading points:', error);
            console.warn('No points.json found. Map will work in development mode only.');
        }
    },

    // Render permanent markers from JSON data
    renderPermanentMarkers() {
        this.points.forEach(point => {
            // Validate point structure
            if (!point.id || !point.name || !point.lat || !point.lng) {
                console.warn('Invalid point structure:', point);
                return;
            }

            // Create marker
            const marker = this.addMarker(point);
            
            // Store marker reference
            this.permanentMarkers.push({
                marker: marker,
                data: point
            });
        });

        console.log(`Rendered ${this.permanentMarkers.length} permanent markers`);
    },

    // Add permanent marker with click event
    addMarker(point) {
        const marker = L.marker([point.lat, point.lng], {
            icon: L.icon({
                iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
                shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
                shadowSize: [41, 41]
            })
        }).addTo(this.map);

        // Bind click event to open sidebar
        marker.on('click', (e) => {
            // Stop propagation to prevent map click
            L.DomEvent.stopPropagation(e);
            
            // Open sidebar with point data
            if (window.UI) {
                window.UI.openSidebar(point);
            }
        });

        return marker;
    },

    // Export temporary markers as JSON
    exportTempMarkers() {
        if (this.tempMarkers.length === 0) {
            alert('No temporary markers to export');
            return;
        }

        const exportData = this.tempMarkers.map((item, index) => ({
            id: `temp_${index + 1}`,
            name: `Point ${index + 1}`,
            lat: parseFloat(item.lat.toFixed(6)),
            lng: parseFloat(item.lng.toFixed(6)),
            description: "Description here",
            stress: 0
        }));

        const jsonString = JSON.stringify(exportData, null, 2);
        
        // Copy to clipboard
        navigator.clipboard.writeText(jsonString).then(() => {
            alert(`Exported ${exportData.length} markers to clipboard!`);
            console.log('Exported data:', jsonString);
        }).catch(err => {
            console.error('Could not copy to clipboard:', err);
            // Fallback: show in console
            console.log('Export data (copy manually):', jsonString);
            alert('Export data logged to console (F12)');
        });
    },

    // Clear all temporary markers
    clearTempMarkers() {
        this.tempMarkers.forEach(item => {
            this.map.removeLayer(item.marker);
        });
        this.tempMarkers = [];
        console.log('All temporary markers cleared');
    }
};

// Expose to window for UI access
window.MapModule = MapModule;
