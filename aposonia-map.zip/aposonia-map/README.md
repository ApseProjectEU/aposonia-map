# Aposonía Map

Interactive geolocation system for sound art performance along Nea Paralia, Thessaloniki.

## Overview

Aposonía Map is a web-based tool for defining, visualizing, and managing precise geographic points along the Thessaloniki waterfront. This system serves as the foundation for an interactive sound art project.

## Features

### Development Mode
* Click anywhere on the map to get precise coordinates (6 decimal precision)
* Create temporary markers for field research
* Export temporary markers as JSON for integration into main dataset

### Production Mode
* Load points from `points.json` data file
* Click markers to view detailed information in sidebar panel
* Visual distinction between temporary (blue) and permanent (red) markers

## Technology Stack

* **Leaflet.js** - Interactive map rendering
* **OpenStreetMap** - Tile layer provider
* **Vanilla JavaScript** - No framework dependencies
* **Modular architecture** - Separated concerns (map, ui, data)

## File Structure

```
aposonia-map/
├── index.html              # Main HTML container
├── css/
│   └── style.css           # Layout and styling
├── js/
│   ├── map.js              # Leaflet logic and marker management
│   ├── ui.js               # Sidebar and coordinate display
│   └── main.js             # Application orchestration
└── data/
    ├── points.json         # Active point dataset
    └── points-example.json # Template for new points
```

## Usage

### Basic Setup

1. Open `index.html` in a modern browser
2. Map initializes centered on Nea Paralia (40.6246°N, 22.9489°E)
3. Click anywhere to see coordinates and create temporary markers

### Working with Points

**View existing points:**
- Red markers appear if `points.json` exists and contains valid data
- Click any red marker to open detail panel with name, description, and stress level

**Define new points:**
1. Click desired location on map
2. Note coordinates in bottom display
3. Click "Export" button to copy temporary markers to clipboard as JSON
4. Paste into `points.json` or save for later integration

### Data Structure

Each point in `points.json` requires:

```json
{
  "id": "unique_identifier",
  "name": "Point Name",
  "lat": 40.624600,
  "lng": 22.948900,
  "description": "Detailed description of location and soundscape",
  "stress": 7
}
```

**Fields:**
* `id` - Unique string identifier
* `name` - Display name for UI
* `lat` - Latitude (decimal degrees, 6 decimals recommended)
* `lng` - Longitude (decimal degrees, 6 decimals recommended)
* `description` - Contextual information about location
* `stress` - Numeric value (project-specific metric)

## Console Commands

The application exposes debugging interfaces:

```javascript
// Clear all temporary markers
MapModule.clearTempMarkers();

// Export current temporary markers
MapModule.exportTempMarkers();

// Access loaded points data
MapModule.points

// Manual sidebar control
UI.openSidebar(pointData);
UI.closeSidebar();
```

## Browser Compatibility

Requires modern browser with support for:
* ES6+ JavaScript
* Fetch API
* Clipboard API (for export functionality)

Tested on: Chrome 90+, Firefox 88+, Safari 14+

## Deployment

### GitHub Pages
1. Push to GitHub repository
2. Settings → Pages → Source: main branch
3. Access at: `username.github.io/aposonia-map`

### Local Server
Any static file server works:
```bash
python -m http.server 8000
# or
npx http-server
```

## Future Development

This is v1 (map infrastructure only). Planned phases:
* Audio integration (Web Audio API)
* Real-time sonification based on location
* Mobile-responsive performance mode
* Data collection workflows

## License

[Specify license]

## Contact

SOS APS (Soundscapes of South Europe)  
Project: Aposonía  
Location: Thessaloniki, Greece
